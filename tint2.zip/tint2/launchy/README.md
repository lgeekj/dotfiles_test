the icons are extracted from min icon pack
