#!/bin/sh

if [ x"${DESKTOP_SESSION##*/}" = x"openbox" ]; then 
   sleep 20s
   killall conky
   cd "$HOME/.conky/MX-Asq/MX-GeekyTowerLogo"
   conky -c "$HOME/.conky/MX-Asq/MX-GeekyTowerLogo/MX-geekytowerLogo" &
   exit 0
fi
