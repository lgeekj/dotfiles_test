## Official Themes

These themes are shipped with latest rofi!

#### Adapta Nokto
![Adapta Nokto](https://53280.de/rofi/Adapta-Nokto.png)

#### android_notifications
![android notifications](https://53280.de/rofi/android_notification.png)

#### Arc
![Arc](https://53280.de/rofi/Arc.png)

#### arthur
![arthur](https://53280.de/rofi/arthur.png)

#### blue
![blue](https://53280.de/rofi/blue.png)

#### c64
![c64](https://53280.de/rofi/c64.png)

#### DarkBlue
![DarkBlue](https://53280.de/rofi/DarkBlue.png)

#### dmenu
![dmenu](https://53280.de/rofi/dmenu1.png)

#### glue_pro_blue
![glue_pro_blue](https://53280.de/rofi/glue_pro_blue.png)

#### gruvbox-dark-hard
![gruvbox-dark-hard](https://53280.de/rofi/gruvbox-dark-hard.png)

#### gruvbox-dark
![gruvbox-dark](https://53280.de/rofi/gruvbox-dark1.png)

#### gruvbox-dark-soft
![gruvbox-dark-soft](https://53280.de/rofi/gruvbox-dark-soft.png)

#### gruvbox-light-hard
![gruvbox-light-hard](https://53280.de/rofi/gruvbox-light-hard1.png)

#### gruvbox-light
![gruvbox-light](https://53280.de/rofi/gruvbox-light2.png)

#### gruvbox-light-soft
![gruvbox-light-soft](https://53280.de/rofi/gruvbox-light-soft2.png)

#### Indego
![Indego](https://53280.de/rofi/Indego1.png)

#### lb
![lb](https://53280.de/rofi/lb.png)

#### Monokai
![Monokai](https://53280.de/rofi/Monokai.png)

#### paper-float
![paper-float](https://53280.de/rofi/paper-float.png)

#### Paper
![Paper](https://53280.de/rofi/Paper.png)

#### Pop-Dark
![Pop-Dark](https://53280.de/rofi/Pop-Dark.png)

#### purple
![purple](https://53280.de/rofi/purple.png)

#### sidebar
![sidebar](https://53280.de/rofi/sidebar.png)

#### solarized_alternate
![solarized_alternate](https://53280.de/rofi/solarized_alternate.png)

#### solarized
![solarized](https://53280.de/rofi/solarized.png)

